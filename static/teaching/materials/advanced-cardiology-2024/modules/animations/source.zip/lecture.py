"""Three original, finite Manim sequences for computational cardiology.
Render with Manim Community 0.20.1, --save_sections, 1920x1080, 24 fps.
Mathematics uses Tectonic and Poppler SVG paths; no browser or remote service.
"""
from pathlib import Path
import hashlib,subprocess,os,sys,importlib.util,json,shutil
import numpy as np
from manim import *
ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
ASSETS=HERE/'assets';ASSETS.mkdir(exist_ok=True)
BG='#081521';INK='#F4F7FB';MUTED='#B1C2CF';BLUE='#5AB0F2';TEAL='#60D9CF';GOLD='#F4C95D';MAGENTA='#F07AA5';LINE='#355268';PANEL='#102638'
config.background_color=BG
Text.set_default(font='DejaVu Sans',color=INK)

def text(s,size=24,color=INK,width=None):
    o=Text(s,font_size=size,color=color)
    if width and o.width>width:o.scale_to_fit_width(width)
    return o

def math(s,width=11,height=.48,color=INK):
    key=hashlib.sha256(s.encode()).hexdigest()[:20];p=ASSETS/key
    if not p.with_suffix('.svg').exists():
        p.with_suffix('.tex').write_text(r'\documentclass[border=2pt]{standalone}\usepackage{amsmath,amssymb,bm}\begin{document}$\displaystyle '+s+r'$\end{document}')
        subprocess.run([os.environ.get('TECTONIC',shutil.which('tectonic') or '/home/zan/Teaching/tools/ch6-env/bin/tectonic'),'-o',str(ASSETS),str(p.with_suffix('.tex'))],check=True,stdout=subprocess.DEVNULL)
        subprocess.run([os.environ.get('PDFTOCAIRO',shutil.which('pdftocairo') or '/usr/bin/pdftocairo'),'-svg',str(p.with_suffix('.pdf')),str(p.with_suffix('.svg'))],check=True)
    o=SVGMobject(str(p.with_suffix('.svg'))).set_color(color).set_height(height)
    if o.width>width:o.scale_to_fit_width(width)
    return o

def header(tag,title,subtitle=''):
    a=text(tag.upper(),16,GOLD).to_corner(UL,buff=.4)
    b=text(title,33,width=12.4).next_to(a,DOWN,buff=.12,aligned_edge=LEFT)
    rule=Line([-6.65,2.5,0],[6.65,2.5,0],color=LINE,stroke_width=1)
    g=VGroup(a,b,rule)
    if subtitle:g.add(text(subtitle,19,MUTED,width=12.5).move_to([0,2.08,0]))
    return g

def note(s):return text(s,18,MUTED,width=12.4).move_to([0,-3.48,0])

def lineplot(points,color=TEAL,width=3):
    m=VMobject(color=color,stroke_width=width);m.set_points_as_corners(points);return m

def panelaxes(xrange,yrange,xlen=7.8,ylen=3.5):
    return Axes(x_range=xrange,y_range=yrange,x_length=xlen,y_length=ylen,tips=False,axis_config={'color':LINE,'stroke_width':2,'include_ticks':True},x_axis_config={'include_numbers':False},y_axis_config={'include_numbers':False})

class Lesson(Scene):
    def begin(self,name,tag,title,subtitle=''):
        self.next_section(name)
        self.clear();self.add(header(tag,title,subtitle))
    def hold(self):self.wait(.8)

class ConservationFlow(Lesson):
    def construct(self):
        self.begin('shared-face','Finite volumes','One face, two opposite contributions','A flux is positive to the right; each cell uses its outward boundary orientation.')
        cells=VGroup(*[Rectangle(width=2.65,height=1.65,color=LINE,fill_color=PANEL,fill_opacity=1).move_to([x,.3,0]) for x in [-2.65,0,2.65]])
        labels=VGroup(*[math(s,height=.45).move_to([x,.3,0]) for x,s in [(-2.65,r'c_{i-1}'),(0,r'c_i'),(2.65,r'c_{i+1}')]])
        arrows=VGroup(*[Arrow([x-.5,1.3,0],[x+.5,1.3,0],buff=0,color=c) for x,c in [(-3.975,BLUE),(-1.325,GOLD),(1.325,GOLD),(3.975,TEAL)]])
        self.play(LaggedStart(*[Create(c) for c in cells],lag_ratio=.15),FadeIn(labels));self.play(Create(arrows))
        eq=math(r'c_i^{n+1}=c_i^n-\frac{\Delta t}{\Delta x}\left(F_{i+1/2}-F_{i-1/2}\right)',height=.58).move_to([0,-1.3,0]);self.play(FadeIn(eq))
        self.add(note('Compute each shared face flux once. Its contribution changes sign in the neighboring cell balance.'));self.hold()
        self.next_section('global-budget')
        self.play(arrows[1].animate.set_color(MAGENTA),arrows[2].animate.set_color(MAGENTA),run_time=.8)
        summed=math(r'M^{n+1}-M^n=\Delta t\left(F_{\rm in}-F_{\rm out}\right),\qquad M^n=\Delta x\sum_i c_i^n',height=.52).move_to([0,-2.4,0])
        self.play(FadeIn(summed),arrows[1].animate.set_opacity(.2),arrows[2].animate.set_opacity(.2));self.hold()
        self.begin('channel','Viscous momentum','Pressure-driven channel flow','Stationary no-slip walls; steady, fully developed motion.')
        ax=panelaxes([0,13,2],[0,2,.5],7.2,3.5).move_to([-2.4,-.25,0]);self.add(ax)
        for x in [0,4,8,12]:self.add(text(str(x),16,MUTED).next_to(ax.c2p(x,0),DOWN,buff=.12))
        for y in [0,1,2]:self.add(text(str(y),16,MUTED).next_to(ax.c2p(0,y),LEFT,buff=.12))
        self.add(text('Axial speed (mm/s)',20).next_to(ax,DOWN,buff=.5),text('y (mm)',20).next_to(ax,UP,buff=.12))
        y=np.linspace(0,2,121);u=12.5*y*(2-y)
        profile=lineplot([ax.c2p(a,b) for a,b in zip(u,y)],TEAL)
        self.play(Create(profile),run_time=2)
        formulas=VGroup(math(r'\mu u^{\prime\prime}=-G',width=4,height=.47),math(r'u(0)=u(H)=0',width=4,height=.4),math(r'u(y)=\frac{G}{2\mu}y(H-y)',width=4,height=.62),math(r'q=\frac{GH^3}{12\mu}',width=4,height=.58)).arrange(DOWN,buff=.35).move_to([4.1,-.15,0]);self.play(LaggedStart(*[FadeIn(a) for a in formulas],lag_ratio=.3),run_time=2)
        self.add(note('H = 2 mm; G = 100 Pa/m; viscosity = 0.004 Pa s. Here q is volume flux per width (m²/s).'));self.hold()
        self.begin('tracer','Advection and diffusion','A packet in a shear flow','Normalized concentration: initial 0; inlet pulse 1 for 0.3 s; impermeable walls.')
        data=np.load(ASSETS/'transport.npz');times=data['snapshot_times'];states=data['snapshots']
        lut=np.load(ASSETS/'viridis.npy')
        def raster(k):
            rgba=lut[np.minimum(255,np.maximum(0,(states[k]*255).astype(int)))];o=ImageMobject(np.flipud(rgba));o.set_resampling_algorithm(RESAMPLING_ALGORITHMS['nearest']);o.stretch_to_fit_width(11.8);o.stretch_to_fit_height(2.0);o.move_to([0,.1,0]);return o
        clock=ValueTracker(0);image=always_redraw(lambda:raster(int(np.argmin(abs(times-clock.get_value())))));time_label=always_redraw(lambda:text(f't = {clock.get_value():.2f} s',23,GOLD).move_to([0,1.55,0]));self.add(clock,image,time_label)
        self.add(text('0 mm',17,MUTED).move_to([-5.8,-1.2,0]),text('20 mm',17,MUTED).move_to([5.7,-1.2,0]),text('H = 2 mm (vertical scale enlarged)',18,MUTED).move_to([0,-1.2,0]))
        cb=np.array([lut]*6);bar=ImageMobject(cb).stretch_to_fit_width(4.6).stretch_to_fit_height(.18).move_to([0,-1.85,0]);self.add(bar,text('0',17,MUTED).move_to([-2.7,-1.85,0]),text('1',17,MUTED).move_to([2.7,-1.85,0]))
        self.add(math(r'\partial_t c+u(y)\partial_xc=D\Delta c',height=.43).move_to([0,-2.65,0]),note('80 × 20 cells; D = 2 × 10⁻⁶ m²/s. The physical model and numerical diffusion must be tested separately.'))
        for target in [.3,1.,2.]:
            k=int(np.argmin(abs(times-target)))
            self.play(clock.animate.set_value(float(times[k])),run_time=2.5,rate_func=linear)
            self.hold()
        self.begin('budget-check','Verification','The discrete budget closes','A conservation check is separate from a convergence study or comparison with data.')
        b=data['budgets'];ax=panelaxes([0,4,1],[0,6,1],9.4,3.5).move_to([0,-.2,0]);self.add(ax)
        for x in range(5):self.add(text(str(x),16,MUTED).next_to(ax.c2p(x,0),DOWN,buff=.1))
        for y in [0,2,4,6]:self.add(text(str(y),16,MUTED).next_to(ax.c2p(0,y),LEFT,buff=.1))
        a=lineplot([ax.c2p(t,m*1e6) for t,m in b[:,:2]],TEAL);bb=lineplot([ax.c2p(t,m*1e6) for t,m in b[:,[0,2]]],GOLD,1.5)
        self.play(Create(a),run_time=2);self.play(Create(bb),run_time=2)
        self.add(text('Time (s)',20).move_to([0,-2.5,0]),text('Normalized tracer area (mm²)',20).move_to([0,1.85,0]),text('Stored tracer',20,TEAL).move_to([-2,-2.95,0]),text('Integrated net boundary inflow',20,GOLD).move_to([2.1,-2.95,0]),note('Maximum cumulative budget defect ≈ 2.4 × 10⁻²⁰ m². Refine the mesh before interpreting spreading.'));self.hold()

class ExcitableWave(Lesson):
    def construct(self):
        data=np.load(ASSETS/'wave-history.npz');x=data['x_mm'];ts=data['time_ms'];v=data['v'];h=data['h'];arr=data['arrivals_ms'];speed=float(data['speed_m_s'])
        self.begin('reaction','Reduced cardiac tissue','Excitation, recovery and spatial coupling','Mitchell–Schaeffer reaction with homogeneous one-dimensional diffusion.')
        eq=VGroup(math(r'\partial_t v=D\partial_{xx}v+\frac{h v^2(1-v)}{\tau_{\rm in}}-\frac{v}{\tau_{\rm out}}+I_{\rm stim}',height=.65),math(r'\partial_t h=\begin{cases}(1-h)/\tau_{\rm open},&v<v_{\rm gate},\\-h/\tau_{\rm close},&v\geq v_{\rm gate}.\end{cases}',height=1.02)).arrange(DOWN,buff=.6).move_to([0,.2,0]);self.play(FadeIn(eq),run_time=1.5)
        self.add(text('v: scaled voltage     h: availability gate     t: ms     x: cm',23,MUTED).move_to([0,-1.9,0]),note('This sequence shows the advancing front. Recovery takes longer than the displayed 80 ms window.'));self.hold()
        self.begin('stimulus','Excitable cable','A localized stimulus launches a front','Sealed ends: ∂v/∂x = 0. Stimulus: 1–3 ms over the first 1 mm.')
        ax=panelaxes([0,20,5],[0,1,.25],10,3.4).move_to([0,-.25,0]);self.add(ax)
        for xx in [0,5,10,15,20]:self.add(text(str(xx),16,MUTED).next_to(ax.c2p(xx,0),DOWN,buff=.12))
        for yy in [0,.5,1]:self.add(text(str(yy),16,MUTED).next_to(ax.c2p(0,yy),LEFT,buff=.12))
        self.add(text('Position (mm)',20).move_to([0,-2.5,0]),text('Scaled voltage v',20,TEAL).move_to([-3.1,1.8,0]),text('Availability h',20,GOLD).move_to([2.2,1.8,0]))
        t=ValueTracker(0)
        def curve(key,col):
            q=np.interp(t.get_value(),ts,np.arange(len(ts)));i=min(int(q),len(ts)-2);w=q-i;z=(1-w)*key[i]+w*key[i+1]
            return lineplot([ax.c2p(xx,yy) for xx,yy in zip(x,z)],col,3)
        cv=always_redraw(lambda:curve(v,TEAL));ch=always_redraw(lambda:curve(h,GOLD));timer=always_redraw(lambda:text(f't = {t.get_value():.1f} ms',22,INK).move_to([4.1,-2.65,0]));self.add(cv,ch,timer,note('D = 0.001 cm²/ms; 200 finite-volume cells; first-order splitting with Δt ≤ 0.02 ms.'))
        self.play(t.animate.set_value(10),run_time=4,rate_func=linear);self.hold()
        self.next_section('propagation');self.play(t.animate.set_value(40),run_time=7,rate_func=linear);self.hold()
        self.next_section('arrival');self.play(t.animate.set_value(80),run_time=6,rate_func=linear);self.hold()
        self.begin('speed','Arrival-time measurement','Two fixed sensors define a measured speed','The threshold crossing time is interpolated between successive stored solver steps.')
        ax=panelaxes([0,80,20],[0,1,.25],8.6,3.4).move_to([-1.5,-.1,0]);self.add(ax)
        for xx in [0,20,40,60,80]:self.add(text(str(xx),16,MUTED).next_to(ax.c2p(xx,0),DOWN,buff=.12))
        for yy in [0,.5,1]:self.add(text(str(yy),16,MUTED).next_to(ax.c2p(0,yy),LEFT,buff=.12))
        self.add(DashedLine(ax.c2p(0,.5),ax.c2p(80,.5),color=MUTED),text('Time (ms)',20).move_to([-1.5,-2.4,0]))
        for j,(pos,col) in enumerate([(6,TEAL),(12,MAGENTA)]):
            trace=data['sensor_traces'][:,j];self.play(Create(lineplot([ax.c2p(tt,z) for tt,z in zip(data['sensor_time'],trace)],col)),run_time=1.5)
            self.add(Dot(ax.c2p(arr[j],.5),color=col),text(f'{pos} mm: {arr[j]:.2f} ms',20,col).move_to([4.4,.8-j*.6,0]))
        eq=math(r's=\frac{(12-6)\,\mathrm{mm}}{t_{12}-t_6}',width=3.6,height=.65).move_to([4.4,-1,0]);self.add(eq,text(f'= {speed:.3f} m/s',25,INK).move_to([4.4,-1.8,0]),note('The measured speed depends on model parameters and discretization. The lecture includes separate space/time refinement.'));self.hold()

class LandmarkFlow(Lesson):
    def curve(self,n=80):
        a=np.linspace(0,TAU,n,endpoint=False);r=1+.15*np.cos(3*a);return np.c_[r*np.cos(a),.75*r*np.sin(a)]
    def construct(self):
        pts=self.curve(16);fine=self.curve();centers=[np.array([-3.6,-.1,0]),np.array([3.6,-.1,0])]
        def obj(a,center,color=TEAL,close=True):
            xy=np.c_[a,np.zeros(len(a))]+center
            return lineplot(np.vstack([xy,xy[:1]]) if close else xy,color,3)
        self.begin('correspondence','Landmark geometry','A distance requires a correspondence','Coordinates use a common frame and the same length unit.')
        a=obj(fine*1.6,centers[0]);b=obj(-fine*1.6,centers[1],MAGENTA);self.play(Create(a),Create(b))
        marks=VGroup(*[Dot(np.r_[p*1.6,0]+centers[0],radius=.045,color=GOLD) for p in pts],*[Dot(np.r_[-p*1.6,0]+centers[1],radius=.045,color=GOLD) for p in pts]);self.add(marks)
        for i in [0,4,8,12]:
            self.add(text(str(i),15,GOLD).move_to(np.r_[pts[i]*1.93,0]+centers[0]),text(str(i),15,GOLD).move_to(np.r_[-pts[i]*1.93,0]+centers[1]))
        self.add(math(r'd(X,Y)=\sqrt{\frac1N\sum_{i=1}^N\|x_i-y_i\|^2}',height=.68).move_to([0,-2.45,0]),note('The lab can center, rotate and scale configurations. Each choice changes what the reported distance means.'));self.hold()
        self.begin('linear-collapse','Coordinate interpolation','A half-turn collapses halfway','Let the target be Y = −X and preserve landmark labels.')
        t=ValueTracker(0);center=np.array([-2.8,-.5,0]);base=self.curve()*1.3
        def grid(c,phi):
            g=VGroup()
            for z in np.linspace(-1.5,1.5,9):
                for xy in [np.c_[np.full(35,z),np.linspace(-1.5,1.5,35)],np.c_[np.linspace(-1.5,1.5,35),np.full(35,z)]]:
                    yy=phi(xy);g.add(obj(yy,c,LINE,False))
            return g
        gg=always_redraw(lambda:grid(center,lambda z:(1-2*t.get_value())*z));cc=always_redraw(lambda:obj((1-2*t.get_value())*base,center,MAGENTA));self.add(gg,cc)
        lab=always_redraw(lambda:text(f't = {t.get_value():.2f}   det DFₜ = {(1-2*t.get_value())**2:.3f}',21,GOLD,width=5.5).move_to([3.5,-1.1,0]));self.add(lab,math(r'F_t(x)=(1-2t)x',width=5.4,height=.5).move_to([3.5,.5,0]),note('At t = 1/2 every point maps to the origin. A positive endpoint determinant does not protect the path.'))
        self.add(always_redraw(lambda:Dot(center,radius=.045,color=MAGENTA).set_opacity(1 if abs(1-2*t.get_value())<.005 else 0)))
        self.play(t.animate.set_value(.5),run_time=4,rate_func=linear);self.hold()
        self.next_section('linear-endpoint');self.play(t.animate.set_value(1),run_time=4,rate_func=linear);self.hold()
        self.begin('rotation-flow','Ambient flow','A smooth rotation reaches the same endpoint','The velocity field specifies motion throughout the ambient plane.')
        t=ValueTracker(0)
        def rot(z):
            theta=PI*t.get_value();mat=np.array([[np.cos(theta),-np.sin(theta)],[np.sin(theta),np.cos(theta)]]);return z@mat.T
        gg=always_redraw(lambda:grid(center,rot));cc=always_redraw(lambda:obj(rot(base),center,TEAL));self.add(gg,cc,VGroup(math(r'\dot\Phi_t=\pi J\Phi_t',width=5,height=.48),math(r'\Phi_t=R_{\pi t}',width=5,height=.48),math(r'\det D\Phi_t=1',width=5,height=.45)).arrange(DOWN,buff=.4).move_to([3.5,0,0]),note('J rotates a vector through 90°. Uniqueness of the smooth ODE prevents trajectory collisions.'))
        self.play(t.animate.set_value(.5),run_time=4,rate_func=linear);self.hold();self.next_section('rotation-endpoint');self.play(t.animate.set_value(1),run_time=4,rate_func=linear);self.hold()
        self.begin('jacobian','Flow and deformation','The Jacobian evolves with the divergence','A numerical integration still needs independent step-size and orientation checks.')
        formula=VGroup(math(r'\dot\Phi_t(x)=u(\Phi_t(x)),\qquad\Phi_0(x)=x',height=.5),math(r'\frac{\mathrm d}{\mathrm dt}D\Phi_t=Du(\Phi_t)D\Phi_t',height=.6),math(r'\det D\Phi_t(x)=\exp\!\left(\int_0^t\nabla\!\cdot u(\Phi_s(x))\,\mathrm ds\right)>0',height=.7)).arrange(DOWN,buff=.5).move_to([0,.25,0]);self.play(LaggedStart(*[FadeIn(q) for q in formula],lag_ratio=.3),run_time=2)
        self.add(text('Exact flow: orientation preserved.   Sampled numerical determinants: diagnostic only.',21,MUTED,width=12).move_to([0,-2.2,0]),note('Rotation is an analytic benchmark. The lab fits a smooth initial velocity; it does not solve geodesic registration.'));self.hold()
