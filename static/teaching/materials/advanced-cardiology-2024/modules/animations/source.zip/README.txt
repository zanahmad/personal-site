Original computational cardiology animation sequences by Zan Ahmad.

Render requirements: Manim Community 0.20.1, Tectonic, Poppler pdftocairo and DejaVu Sans. Put tectonic and pdftocairo on PATH (or set TECTONIC and PDFTOCAIRO).

Run: manim render --renderer cairo -r 1920,1080 --fps 24 --save_sections lecture.py ConservationFlow ExcitableWave LandmarkFlow

The cached NPZ files are numerical outputs, not animation approximations of a drawing. The CFD source uses SI units; wave_solver.py uses cm and ms and its own documented nondimensional voltage. The wave animation plots x in mm. The deformation example is an analytic rotation benchmark, not a fitted geodesic.

Style references: the author's probability counting and covariance/regression Manim lectures. The original Avenir Next font is unavailable on this Linux host, so the new sequences use DejaVu Sans; equations are actual LaTeX outlines.
